"""Continue verified raw samples within the original remaining phase budgets."""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
import shutil
import time

from draft_assistant import campaign as runner
from draft_assistant import campaign_counterfactual as counter
from draft_assistant import campaign_engine as engine
from draft_assistant.campaign_data import projection_dataset

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / "runtime/strategy-quality-2026-10-14-v3"
OUT = ROOT / "runtime/strategy-quality-2026-10-14-final"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def function_asts(path):
    return {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(path.read_text()).body
            if isinstance(node, ast.FunctionDef)}


def main():
    start = time.monotonic()
    manifest = json.loads((OLD / "manifest.json").read_text())
    changed_controls = {"draft_assistant/campaign.py", "draft_assistant/campaign_counterfactual.py"}
    for relative, expected in manifest["source_sha256"].items():
        if relative.replace("\\", "/") not in changed_controls:
            assert digest(ROOT / relative) == expected, relative
    before = function_asts(OLD / "sources/draft_assistant/campaign.py")
    after = function_asts(ROOT / "draft_assistant/campaign.py")
    for name in ("run_job", "compare_rows", "summarize", "make_tasks", "cluster_interval"):
        assert before[name] == after[name], name
    before_counter = function_asts(OLD / "sources/draft_assistant/campaign_counterfactual.py")
    after_counter = function_asts(ROOT / "draft_assistant/campaign_counterfactual.py")
    for name in ("_single_branch_row", "_evaluate", "_metric", "_call_simulate", "_generate_continuation_world"):
        assert before_counter[name] == after_counter[name], name

    OUT.mkdir(parents=True, exist_ok=True)
    code_hash = runner.fingerprint()
    runner.write_json(OUT / "manifest.json", {
        "fingerprint": code_hash, "production_policy_frozen": True,
        "remaining_phase_budgets_seconds": {"monte_carlo": 1200, "counterfactual": 1140},
        "continuation_runner_sha256": digest(Path(__file__)),
        "original_run": str(OLD), **runner.snapshot_sources(OUT),
    })
    shutil.copyfile(__file__, OUT / "sources/continue_quality_campaign.py")
    base = projection_dataset()
    dataset_path = OUT / "datasets/projection.json"
    runner._save_dataset(dataset_path, base)
    assert json.loads(dataset_path.read_text()) == json.loads((OLD / "datasets/projection.json").read_text())
    mc_deadline = time.monotonic() + 1200
    tasks = runner.make_tasks([(base.name, dataset_path)], experiment="monte_carlo", seeds=16,
                             output=OUT, code_fingerprint=code_hash, deadline=mc_deadline,
                             seats=list(range(1, 15)))
    by_cell = {(task["environment"], task["opponent"], task["seed"]): task for task in tasks}
    imported = []
    for path in (OLD / "jobs").glob("*.json"):
        result = json.loads(path.read_text())
        if result.get("status") != "complete":
            continue
        rows = result["rows"]
        assert len(rows) == 84 and len({(row["seat"], row["policy"]) for row in rows}) == 84
        cells = {(row["environment"], row["opponent"], row["seed"]) for row in rows}
        assert len(cells) == 1
        task = by_cell[cells.pop()]
        old_id = result["job_id"]
        result["job_id"] = task["job_id"]
        result["fingerprint"] = code_hash
        result["resume_import"] = {"original_job_id": old_id, "original_fingerprint": manifest["fingerprint"],
                                   "original_sources": str(OLD / "sources"), "all_scoring_math_unchanged": True}
        trace_path = OUT / "traces" / f"{task['job_id']}.jsonl.gz"
        trace_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(OLD / "traces" / f"{old_id}.jsonl.gz", trace_path)
        runner.write_json(OUT / "jobs" / f"{task['job_id']}.json", result)
        imported.append(task["job_id"])
    runner.write_json(OUT / "RESUME_AUDIT.json", {"source_run": str(OLD), "imported_jobs": imported,
        "validation": "Every model/data source hash matches; every scoring/statistical function AST matches."})
    print(f"Resumed {len(imported)} completed tournament jobs", flush=True)
    results = runner.run_phase(tasks, workers=3, deadline=mc_deadline)

    counter_start = time.monotonic()
    counter_deadline = counter_start + 1140
    world = engine.generate_world(base, seed=runner.SEED_START + 10000, environment="moderate")
    frozen = engine.simulate_draft(world.players, 13, runner.SEED_START + 10000, "nominal", "marginal", deadline=counter_deadline)
    assert frozen["status"] == "complete"
    runner.write_json(OUT / "frozen-draft.json", frozen)
    original_checkpoint = json.loads((OLD / "counterfactual.json").read_text())
    schedule = counter._continuation_schedule(runner.SEED_START + 20000, 32)
    identity = counter._checkpoint_identity(world, frozen, engine, seed=runner.SEED_START + 20000,
                                            continuations=32, our_seat=13, schedule=schedule)
    for name in ("base_history_digest", "forecast_outcome_digest", "seed", "target_seeds", "target_splits"):
        assert original_checkpoint["checkpoint_identity"][name] == identity[name], name
    original_identity = original_checkpoint["checkpoint_identity"]
    original_checkpoint["checkpoint_identity"] = identity
    original_checkpoint["checkpoint_migration"] = {
        "original_identity": original_identity, "source_run": str(OLD),
        "validation": "Model and single-branch scoring unchanged; fixes only retry/report control and pair baseline status metadata.",
    }
    checkpoint_path = OUT / "counterfactual.json"
    runner.write_json(checkpoint_path, original_checkpoint)
    shutil.copyfile(OLD / "counterfactual.json.traces.jsonl.gz", OUT / "counterfactual.json.traces.jsonl.gz")
    print("Continuing verified counterfactual branches; maximum remaining time 19 minutes", flush=True)
    cf = counter.run_counterfactuals(world, frozen, seed=runner.SEED_START + 20000, continuations=32,
                                    deadline=counter_deadline, checkpoint_path=checkpoint_path)
    rows = [row for result in results if result["status"] == "complete" for row in result["rows"]]
    previous = json.loads((OLD / "summary.json").read_text())
    summary = {**previous, "fingerprint": code_hash, "elapsed_seconds": time.monotonic() - start,
        "continuation_phase_seconds": {"monte_carlo": counter_start - start, "counterfactual": time.monotonic() - counter_start},
        "completed_jobs": sum(result["status"] == "complete" for result in results), "target_jobs": len(tasks),
        "counterfactual": runner.compact_counterfactual(cf),
        "experiments": {"historical": previous["experiments"]["historical"], "monte_carlo": runner.summarize(rows)},
        "diagnostics": [{key: value for key, value in result.items() if key != "rows"} for result in results if result["status"] != "complete"],
        "policy_fallbacks": sum(row.get("policy_fallbacks", 0) for row in rows),
        "feasibility_interventions": sum(row.get("feasibility_interventions", 0) for row in rows),
    }
    summary["targets"]["monte_carlo_jobs_completed"] = summary["completed_jobs"]
    summary["limitations"] += ["Market order is a source-order proxy, not measured ADP; GP availability is inferred from rounded ESPN fantasy totals/averages.",
                               "This continuation reuses source-verified raw samples; all input/model/scoring math was frozen."]
    runner.write_json(OUT / "summary.json", summary)
    (OUT / "REPORT.md").write_text(runner.markdown_report(summary), encoding="utf-8")
    print(f"Finished: {OUT / 'REPORT.md'}", flush=True)


if __name__ == "__main__":
    main()
